Haemanth Santhi Ponnusamy <haemanth.santhi-ponnusamy@student.uni-tuebingen.de>
Python


usage:
  python flesch_kincaid.py --input-dir <input directory path> --output-file <output file path>
  

example:

  # Default output file path = 'results.csv'
  python flesch_kincaid.py --input-dir ./newsela-sample 

  # or

  python flesch_kincaid.py --input-dir ./newsela-sample --output-file results.csv
